clc;
clear;

x = -150000:1:150000;     %ba tavajoh be max&min net1
y = sig(x');
plot(x,y)

%%
y=dec2bin(y);
SIG = table(y);
writetable( SIG ,'sig_data.txt');
