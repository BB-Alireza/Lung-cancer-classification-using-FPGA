function out=sig(in)
    out = round(10000./(1 + exp(-in/10000)));
end