clc;
clear;

x = 0:1:10000;     %ba tavajoh be max&min o1
y = dsig(x');
plot(x,y)

y=dec2bin(y);
SIG = table(y);
writetable( SIG ,'dsig_data.txt');
