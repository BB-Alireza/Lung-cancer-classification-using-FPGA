function dAct=dsig(in)
    dAct = round(in.*(1-in/10000));
end