clc;
clear;

load('data.mat');

x1_train = round(x_train(:,1).*10000);
x2_train = round(x_train(:,2).*10000);
y_train  = round(y_train     .*10000);
x1_test  = round(x_test(:,1) .*10000);
x2_test  = round(x_test(:,2) .*10000);
y_test   = round(y_test      .*10000);

%%
x1_train=dec2bin(x1_train,14);   %hame 14 bit shavand
x2_train=dec2bin(x2_train,14);
y_train=dec2bin(y_train,13);
x1_test=dec2bin(x1_test,14);
x2_test=dec2bin(x2_test,14);
y_test=dec2bin(y_test,14);


x1_train = table(x1_train);
x2_train = table(x2_train);
y_train  = table(y_train);
x1_test  = table(x1_test);
x2_test  = table(x2_test);
y_test   = table(y_test);


writetable( x1_train ,'x1_train.txt');
writetable( x2_train ,'x2_train.txt');
writetable( y_train  ,'y_train.txt') ;
writetable( x1_test  ,'x1_test.txt') ;
writetable( x2_test  ,'x2_test.txt') ;
writetable( y_test   ,'y_test.txt')  ;
